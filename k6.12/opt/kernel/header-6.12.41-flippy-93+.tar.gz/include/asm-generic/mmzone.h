/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_GENERIC_MMZONE_H
#define _ASM_GENERIC_MMZONE_H

#endif
