/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_GENERIC_KDEBUG_H
#define _ASM_GENERIC_KDEBUG_H

enum die_val {
	DIE_UNUSED,
	DIE_OOPS = 1,
};

#endif /* _ASM_GENERIC_KDEBUG_H */
